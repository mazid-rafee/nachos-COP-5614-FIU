#include "copyright.h"
#include "system.h"
#include "synch.h"
#include "elevator.h"


enum Direction {UP, DOWN, IDLE};

struct Floor *floors;
Condition* elevatorCondition;
Lock* elevatorLock;
Direction direction = UP;
int currFloor = 0;
int occupied = 0;
int elevatorCapacity = 5;
int nextID = 0;

void initializeElevator(int numFloors)
{
    floors = new struct Floor[numFloors];

    for(int i = 0; i < numFloors; i++)
    {
        floors[i].gettingOn = 0;
        floors[i].gettingOff = 0;
    }

    elevatorCondition = new Condition("Elevator's Condtion");
    elevatorLock = new Lock("Elevator's Lock");
    currFloor = -1;
    occupied = 0;
    direction = UP;
}

void runElevator(int numFloors)
{
    while (TRUE)
    {
        elevatorLock->Acquire();
        
        int waitingPreiod = 0 ;
        while (TRUE)
        {
            waitingPreiod++;
            if (waitingPreiod == 100000000)
            {
                break;
            }
        }
        

        if(direction == UP)
        {
            currFloor++;
        }
        else if(direction == DOWN)
        {
            currFloor--;
        }
        else
        {
            break;
        }

        printf("Elevator arrives at floor %d.\n", currFloor + 1);

        elevatorLock->Release();
        currentThread->Yield(); 

        if(currFloor == numFloors - 1)
        {
            direction = DOWN;
        }
        else if(currFloor == 0)
        {
            direction = UP;
        }

        elevatorLock->Acquire();
        elevatorCondition->Broadcast(elevatorLock);
        elevatorLock->Release();
        elevatorLock->Acquire();

        while(floors[currFloor].gettingOff > 0)
        {
            elevatorCondition->Wait(elevatorLock);
        }

        elevatorLock->Release();
        elevatorLock->Acquire();
        elevatorCondition->Broadcast(elevatorLock);

        while(occupied < elevatorCapacity && floors[currFloor].gettingOn > 0)
        {
            elevatorCondition->Wait(elevatorLock);    
        }

        elevatorLock->Release();
    }
}

void Elevator(int numFloors)
{
    Thread* elevator = new Thread("Elevator Thread");
    initializeElevator(numFloors);
    elevator->Fork(runElevator, numFloors);
}

void runPerson(int p)
{
    Person * person = (Person *) p;
    elevatorLock->Acquire();

    floors[person->atFloor-1].gettingOn++;
    printf("Person %d wants to go to floor %d from floor %d.\n", person->id, person->toFloor, person->atFloor);

    elevatorLock->Release();
    elevatorLock->Acquire();

    while(currFloor != person->atFloor-1 || occupied == elevatorCapacity)
    {
        elevatorCondition->Wait(elevatorLock);
    }

    elevatorLock->Release();
    elevatorLock->Acquire();

    floors[person->toFloor-1].gettingOff++;
    floors[person->atFloor-1].gettingOn--;
    occupied++;

    printf("Person %d got into the elevator at floor %d.\n", person->id, currFloor + 1);
    elevatorCondition->Broadcast(elevatorLock);

    elevatorLock->Release();
    elevatorLock->Acquire();

    while(currFloor != person->toFloor-1)
    {
        elevatorCondition->Wait(elevatorLock);
    }
   
    occupied--;
    printf("Person %d got out of the elevator at floor %d.\n", person->id, currFloor+1); 
    floors[person->toFloor-1].gettingOff--;

    elevatorCondition->Broadcast(elevatorLock);
    elevatorLock->Release();
}

void ArrivingGoingFromTo(int atFloor, int toFloor)
{
    Thread* person = new Thread("Person Thread");
    Person *p = new Person;
    
    p->atFloor = atFloor;
    p->toFloor = toFloor;
    p->id = nextID++;
    person->Fork(runPerson,(int)p);
}