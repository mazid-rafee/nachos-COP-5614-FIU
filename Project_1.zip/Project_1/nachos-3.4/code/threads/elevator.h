#ifndef ELEVATOR_H
#define ELEVATOR_H

#include "copyright.h"

struct Floor
{
    int gettingOn;
    int gettingOff;
};

struct Person
{
    int id;
    int atFloor;
    int toFloor;
};

void Elevator(int numFloors);
void ArrivingGoingFromTo(int atFloor, int toFloor);

#endif